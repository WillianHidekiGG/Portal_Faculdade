package com.example.idportal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

public class Login extends AppCompatActivity {


    private TextView text_tela_esqueci_senha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        getSupportActionBar().hide();
        iniciarComponentes();

        text_tela_esqueci_senha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent proxima_tela = new Intent(Login.this,esqueci_senha.class);
                startActivity(proxima_tela);
            }
        });

    }

    private void iniciarComponentes(){

       text_tela_esqueci_senha = findViewById(R.id.esquecisenha);
    }

}