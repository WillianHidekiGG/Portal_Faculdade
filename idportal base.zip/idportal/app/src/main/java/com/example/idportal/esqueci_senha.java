package com.example.idportal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class esqueci_senha extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_esqueci_senha);
    }
}